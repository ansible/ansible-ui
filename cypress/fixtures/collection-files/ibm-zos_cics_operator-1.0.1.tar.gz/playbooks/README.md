# playbooks

Placeholder file to ensure the directory exists in git and ends up in the operator tar.gz to workaround issue discussed on Slack:
https://ibm-systems-z.slack.com/archives/G5VN2QH8U/p1687772179795039?thread_ts=1687770380.782169&cid=G5VN2QH8U

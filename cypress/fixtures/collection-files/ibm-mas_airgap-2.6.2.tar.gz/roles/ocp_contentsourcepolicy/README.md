ocp_contentsourcepolicies
=========================

TODO: Write me!

!!! warning
   This doesn't work on IBMCloud ROKS.  IBM Cloud RedHat OpenShift Service does not implement support for `ImageContentSourcePolicies`.  If you want to use image mirroring you must manually configure each worker node individually using the IBM Cloud command line tool.

# Ansible role: zmf_workflow_complete
The collection [ibm_zosmf](../../README.md) provides an [Ansible role](https://docs.ansible.com/ansible/latest/user_guide/playbooks_reuse_roles.html), referred to as `zmf_workflow_complete`, to complete a z/OS workflow, either forcibly or idempotently.

For guides and reference, see [Docs Site](https://ibm.github.io/z_ansible_collections_doc/ibm_zosmf/docs/source/roles/zmf_workflow_complete.html).

## Copyright
© Copyright IBM Corporation 2021
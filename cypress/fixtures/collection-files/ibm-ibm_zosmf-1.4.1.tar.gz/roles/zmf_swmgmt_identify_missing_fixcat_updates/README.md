# Ansible role: zmf_swmgmt_identify_missing_fixcat_updates
The collection [ibm_zosmf](../../README.md) provides an [Ansible role](https://docs.ansible.com/ansible/latest/user_guide/playbooks_reuse_roles.html), referred to as `zmf_swmgmt_identify_missing_fixcat_updates`, to run the software instance missing fixcat updates report REST API.

For guides and reference, see [Docs Site](https://ibm.github.io/z_ansible_collections_doc/ibm_zosmf/docs/source/roles/zmf_swmgmt_identify_missing_fixcat_updates.html).

## Copyright
© Copyright IBM Corporation 2023
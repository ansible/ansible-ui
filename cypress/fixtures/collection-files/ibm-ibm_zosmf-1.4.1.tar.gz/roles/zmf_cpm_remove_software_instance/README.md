# Ansible Role: zmf_cpm_remove_software_instance
The collection [ibm_zosmf](../../README.md) provides an [Ansible role](https://docs.ansible.com/ansible/latest/user_guide/playbooks_reuse_roles.html), referred to as `zmf_cpm_remove_software_instance`, to remove a deprovisioned instance of z/OS middleware/software.

For guides and reference, see [Docs Site](https://ibm.github.io/z_ansible_collections_doc/ibm_zosmf/docs/source/roles/zmf_cpm_remove_software_instance.html).

## Copyright
© Copyright IBM Corporation 2021

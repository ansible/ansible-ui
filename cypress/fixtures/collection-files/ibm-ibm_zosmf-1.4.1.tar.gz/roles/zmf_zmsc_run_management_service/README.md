# Ansible Role: zmf_zmsc_run_management_service
The collection [ibm_zosmf](../../README.md) provides an [Ansible role](https://docs.ansible.com/ansible/latest/user_guide/playbooks_reuse_roles.html), referred to as `zmf_zmsc_run_management_service`, to to run a z/OS management service published in z/OS Management Services Catalog.

For guides and reference, see [Docs Site](https://ibm.github.io/z_ansible_collections_doc/ibm_zosmf/docs/source/roles/zmf_zmsc_run_management_service.html).

## Copyright
© Copyright IBM Corporation 2023
